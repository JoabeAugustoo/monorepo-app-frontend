import { FormEvent, useState } from 'react';
import {
  Alert,
  alpha,
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  IconButton,
  InputAdornment,
  Link,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
  useTheme,
} from '@mui/material';
import EmailIcon from '@mui/icons-material/Email';
import PersonIcon from '@mui/icons-material/Person';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { useNavigate } from 'react-router-dom';
import { LoginPageConfig } from '../types';
import { useAuth } from '../hooks/useAuth';

interface LoginPageProps extends LoginPageConfig {
  appName: string;
}

export function LoginPage({
  mode,
  logo,
  titulo,
  subtitulo,
  mostrarEsqueciSenha,
  onEsqueciSenha,
  onSubmit,
  textoBotao = 'Entrar',
  appName,
  corFundo,
}: LoginPageProps) {
  const theme = useTheme();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [identificador, setIdentificador] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState('');
  const [tipoIdentificador, setTipoIdentificador] = useState<'email' | 'username'>(
    mode === 'username' ? 'username' : 'email',
  );

  const labelIdentificador = tipoIdentificador === 'email' ? 'E-mail' : 'Usuário';
  const tipoInput = tipoIdentificador === 'email' ? 'email' : 'text';
  const iconeIdentificador =
    tipoIdentificador === 'email' ? <EmailIcon /> : <PersonIcon />;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErro('');
    setCarregando(true);
    try {
      const resposta = await onSubmit({ identificador, senha, tipoIdentificador });
      login(resposta);
      navigate('/', { replace: true });
    } catch (error) {
      setErro(error instanceof Error ? error.message : 'Erro ao fazer login');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: corFundo
          ? `linear-gradient(135deg, ${corFundo} 0%, ${alpha(corFundo, 0.6)} 100%)`
          : `linear-gradient(135deg, ${alpha(theme.palette.primary.dark, 0.85)} 0%, ${alpha(theme.palette.primary.main, 0.5)} 100%)`,
        p: 2,
      }}
    >
      <Card sx={{ maxWidth: 420, width: '100%', borderRadius: 3, boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}>
        <CardContent
          component="form"
          onSubmit={handleSubmit}
          sx={{ display: 'flex', flexDirection: 'column', gap: 2, p: 4 }}
        >
          {logo && (
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>{logo}</Box>
          )}

          <Typography variant="h5" textAlign="center" fontWeight={600}>
            {titulo ?? appName}
          </Typography>

          {subtitulo && (
            <Typography variant="body2" textAlign="center" color="text.secondary">
              {subtitulo}
            </Typography>
          )}

          {mode === 'both' && (
            <ToggleButtonGroup
              value={tipoIdentificador}
              exclusive
              onChange={(_, valor) => {
                if (valor) setTipoIdentificador(valor);
              }}
              fullWidth
              size="small"
            >
              <ToggleButton value="email">E-mail</ToggleButton>
              <ToggleButton value="username">Usuário</ToggleButton>
            </ToggleButtonGroup>
          )}

          <TextField
            label={labelIdentificador}
            type={tipoInput}
            value={identificador}
            onChange={(e) => setIdentificador(e.target.value)}
            fullWidth
            slotProps={{
              input: {
                startAdornment: (
                  <InputAdornment position="start">
                    {iconeIdentificador}
                  </InputAdornment>
                ),
              },
            }}
          />

          <TextField
            label="Senha"
            type={mostrarSenha ? 'text' : 'password'}
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            fullWidth
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setMostrarSenha(!mostrarSenha)}
                      edge="end"
                      size="small"
                    >
                      {mostrarSenha ? <VisibilityOffIcon /> : <VisibilityIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }}
          />

          {mostrarEsqueciSenha && (
            <Link
              component="button"
              type="button"
              variant="body2"
              onClick={onEsqueciSenha}
              sx={{ alignSelf: 'flex-end', mt: -1 }}
            >
              Esqueci minha senha
            </Link>
          )}

          {erro && <Alert severity="error">{erro}</Alert>}

          <Button
            type="submit"
            variant="contained"
            size="large"
            fullWidth
            disabled={carregando || !identificador || !senha}
            sx={corFundo ? {
              bgcolor: corFundo,
              '&:hover': { bgcolor: alpha(corFundo, 0.85) },
            } : undefined}
          >
            {carregando ? <CircularProgress size={24} color="inherit" /> : textoBotao}
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
}
